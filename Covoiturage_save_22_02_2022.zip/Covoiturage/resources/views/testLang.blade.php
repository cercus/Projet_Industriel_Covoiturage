<!DOCTYPE html>
<html>
    <head>

    </head>
    <body>
        <a href="locale/en">Mettre en anglais</a>
        <br/>
        <a href="locale/fr">Mettre en français</a>
        <p>{{  __("Accueil") }}</p>
    </body>
</html>