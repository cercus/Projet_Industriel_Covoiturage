<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
  </head>
  <body>
    <p>Réception d'une prise de contact avec les éléments suivants :</p>
    <ul>
      <li><strong>Email</strong> : <?php echo e($contact['email']); ?></li>
      <li><strong>Objet</strong> : <?php echo e($contact['objet']); ?></li>
      <li><strong>Message</strong> : <?php echo e($contact['message']); ?></li>
      
    </ul>
  </body>
</html><?php /**PATH D:\Users\doria\Documents\Scolaire\faculté\M2 CCI\Projet\Site_covoiturage\Covoiturage\resources\views/emails/question.blade.php ENDPATH**/ ?>