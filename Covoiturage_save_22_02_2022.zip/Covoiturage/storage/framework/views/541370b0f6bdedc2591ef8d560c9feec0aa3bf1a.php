

<?php $__env->startSection('title'); ?>
<?php echo e(__('Poser une question')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="css/style.css">
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('navbarSequel'); ?>
    <?php if(session()->has('user')): ?>
        <ul class="navbar-nav mr-auto"> 
            <li class="nav-item">
                <a class="nav-link" href="#">Ismail IDBOURHIM</a>
            </li>
        </ul>
        <div class="pmd-user-info ">
            <a href="javascript:void(0);" class="nav-user-img" >   
                <img class="avatar-img rounded-circle" src="/images/avatar_photo.jpg" width="73" height="73" alt="avatar">
            </a>
        </div>
    <?php else: ?>
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="#">Inscription</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Connexion</a>
            </li>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<h1 class="center-title"><?php echo e(__('Poser une question')); ?></h1>

<div style="padding-top: 60px; text-indent: 30px;" class="col-md-8 mx-auto">
    <?php echo e(__('Une question, une remarque, une idée en lien avec site ? Remplissez le formulaire et nous vous répondrons dans les plus brefs délai.')); ?>

</div>

<form style="padding-top: 60px;" method="POST" action="<?php echo e(route('store.question')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-warning">
            La question n'a pas pu etre posé &#9785; <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
                  <?php echo e(session()->get('success')); ?>&#9786;
        </div>
    <?php endif; ?>
    <div class="form-group col-md-8 mx-auto">
        <label for="email"><?php echo e(__('Adresse mail')); ?></label>
        <input type="email" id="email" name="email" class="input-form <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('email')); ?>"/>
    </div>

    <div class="form-group col-md-8 mx-auto">
        <label for="objet"><?php echo e(__('Objet')); ?></label>
        <input type="text" id="objet" name="objet" class="input-form <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('objet')); ?>"/>
        <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="objet_feedback" class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-8 mx-auto">
        <label for="message"><?php echo e(__('Message')); ?></label>
        <textarea class="form-control textarea-form <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="message" name="message" rows=3></textarea>
        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="message_feedback" class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <button type="submit" class="btn button-form mx-auto"><?php echo e(__('Envoyer')); ?></button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\doria\Documents\Scolaire\faculté\M2 CCI\Projet\Site_covoiturage\Covoiturage\resources\views/question.blade.php ENDPATH**/ ?>