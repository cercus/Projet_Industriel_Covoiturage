

<?php $__env->startSection('title', 'Inscription sur le site'); ?>

<?php $__env->startSection('content'); ?>

<form>
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col">
            <!-- Nom de l'utilisateur  -->
            <label for="nom">Votre nom*</label>
            <input type="text" class="form-control" id="nom" name="nom" value="<?php echo e(old('nom')); ?>" />
        </div>
        <div class="col">
            <!-- Prenom de l'utilisateur  -->
            <label for="prenom">Votre prénom*</label>
            <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo e(old('prenom')); ?>" />
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <!-- Email de l'utilisateur  -->
            <label for="email">Votre Adresse mail*</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" />
        </div>
        <div class="col">
            <!-- Mdp de l'utilisateur  -->
            <label for="password">Votre mot de passe*</label>
            <input type="password" class="form-control" id="password" name="password" aria-describedby="passwordHelpBlock" />
            <small id="passwordHelpBlock" class="form-text text-muted">Votre mot de passe doit faire entre 8 et 20 caractères et contenir au moins 1 caractère special</small>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <!-- Mdp (repeter) de l'utilisateur  -->
            <label for="passwordCheck">Repétez votre mot de passe*</label>
            <input type="password" class="form-control" id="passwordCheck" name="passwordCheck"/>
        </div>
        <div class="col">
            <!-- Date de naissance de l'utilisateur  -->
            <label for="birthdate">Votre date de naissance</label>
            <input type="date" class="form-control" id="birthdate" name="birthdate" />
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <!-- Numéro de telephone de l'utilisateur  -->
            <label for="telephone">Votre numéro de telephone*</label>
            <input type="telephone" class="form-control" id="telephone" name="telephone"/>
        </div>
        <div class="col">
            <!-- Photo de profil de l'utilisateur  -->
            <label for="photo">Votre photo de profil</label>
            <input type="file" class="form-control-file" id="photo" name="photo" />
        </div>
    </div>
    <div class="row mt-4">Inscription en tant que : </div>
    <div class="row mt-4">
        
        <div class="form-check">
            <!-- checkBox estConducteur  -->
            <div class="col">
                <span class="col-md-4">
                    <input type="checkbox" class="form-check-input" id="estConducteur"/>
                    <label for="estConducteur">Conducteur</label>
                </span>
                <span class="col-md-4">
                    <input type="checkbox" class="form-check-input" id="estPassager"/>
                    <label for="estPassager">Passager</label>
                </span>
              
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\doria\Documents\Scolaire\faculté\M2 CCI\Projet\Site_covoiturage\Covoiturage\resources\views/register.blade.php ENDPATH**/ ?>