

<?php $__env->startSection('title'); ?>
    Mon profil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/style.css">
<?php $__env->stopSection(); ?>
           
<?php $__env->startSection('navbarSequel'); ?>
    <ul class="navbar-nav mr-auto"> 
        <li class="nav-item">
            <a class="nav-link" href="#">Ismail IDBOURHIM</a>
        </li>
    </ul>
    <div class="pmd-user-info ">
        <a href="javascript:void(0);" class="nav-user-img" >   
            <img class="avatar-img rounded-circle" src="/images/avatar_photo.jpg" width="73" height="73" alt="avatar">
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="text-align: center">
<div class="row justify-content-center align-items-center">
        <div class="col-md-3">
        1 of 3
        </div>
        <div class="col-md-3">
        Variable width content
        </div>
        <div class="col col-md-3">
        3 of 3
        </div>
        <div class="col col-md-3">
        3 of 3
        </div>
</div>
<div class="row justify-content-md-center">
        <div class="col col-lg-2">
        1 of 3
        </div>
        <div class="col-md-auto">
        Variable width content
        </div>
        <div class="col col-lg-2">
        3 of 3
        </div>
</div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\doria\Documents\Scolaire\faculté\M2 CCI\Projet\Site_covoiturage\Covoiturage\resources\views/user.blade.php ENDPATH**/ ?>