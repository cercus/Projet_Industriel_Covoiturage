<!DOCTYPE html>
<html>
    <head>

    </head>
    <body>
        <a href="locale/en">Mettre en anglais</a>
        <br/>
        <a href="locale/fr">Mettre en français</a>
        <p><?php echo e(__("Accueil")); ?></p>
    </body>
</html><?php /**PATH D:\Users\doria\Documents\Scolaire\faculté\M2 CCI\Projet\Site_covoiturage\Covoiturage\resources\views/testLang.blade.php ENDPATH**/ ?>