

<?php $__env->startSection('title'); ?>
    Page d'accueil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/style.css">
<?php $__env->stopSection(); ?>
           
<?php $__env->startSection('navbarSequel'); ?>
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" href="#">Inscription</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Connexion</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Contenu de la page d'accueil
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\doria\Documents\Scolaire\faculté\M2 CCI\Projet\Site_covoiturage\Covoiturage\resources\views/home.blade.php ENDPATH**/ ?>