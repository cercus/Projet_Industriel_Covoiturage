

<?php $__env->startSection('title'); ?>
Inscription
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="css/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbarSequel'); ?>
    <?php if(session()->has('user')): ?>
        <ul class="navbar-nav mr-auto"> 
            <li class="nav-item">
                <a class="nav-link" href="#">Ismail IDBOURHIM</a>
            </li>
        </ul>
        <div class="pmd-user-info ">
            <a href="javascript:void(0);" class="nav-user-img" >   
                <img class="avatar-img rounded-circle" src="/images/avatar_photo.jpg" width="73" height="73" alt="avatar">
            </a>
        </div>
    <?php else: ?>
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="/inscription">Inscription</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/connexion">Connexion</a>
            </li>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="center-title">S'inscrire sur le site</h1>

<form id="register">
    <?php echo csrf_field(); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-warning">
           Impossible de s'inscrire &#9785; <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
                  <?php echo e(session()->get('success')); ?>&#9786;
        </div>
    <?php endif; ?>

    <div class="col-md-8 mx-auto" style="padding-top: 20px;">

        <!-- Nom -->
        <div class="col-right-input">
            <label for="nom">Nom*</label>
            <input type="text" class="input-form <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nom" name="nom" required value="<?php echo e(old('nom')); ?>" aria-describedby="nomError">
            <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="nomError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- prenom -->
        <div class="col-left-input">
            <label for="prenom">Prénom*</label>
            <input type="text" class="input-form <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="prenom" name="prenom" required value="<?php echo e(old('prenom')); ?>" aria-describedby="prenomError">
            <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="prenomError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>      
    </div>

    <div class="col-md-8 mx-auto" style="padding-top: 20px;">

        <!-- Adresse mail -->
        <div class="col-right-input">
            <label for="email">Adresse mail*</label>
            <input type="email" class="input-form <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" required value="<?php echo e(old('email')); ?>" aria-describedby="emailError">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="emailError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Mot de passe -->
        <div class="col-left-input">
            <label for="mdp">Mot de passe*</label>
            <input type="password" class="input-form <?php $__errorArgs = ['mdp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="mdp" name="mdp" required aria-describedby="mdpError">
            <?php $__errorArgs = ['mdp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="mdpError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>      
    </div>

    <div class="col-md-8 mx-auto" style="padding-top: 20px;">

        <!-- Mot de passe 2 -->
        <div class="col-right-input">
            <label for="repeterMdp">Répétez mot de passe*</label>
            <input type="password" class="input-form <?php $__errorArgs = ['repeterMdp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="repeterMdp" name="repeterMdp" required aria-describedby="mdp2Error">
            <?php $__errorArgs = ['repeterMdp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="mdp2Error" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Date de naissance -->
        <div class="col-left-input">
            <label for="dateNaiss">Date de naissance</label>
            <input type="date" class="input-form <?php $__errorArgs = ['dateNaiss'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dateNaiss" name="dateNaiss" value="<?php echo e(old('dateNaiss')); ?>" aria-describedby="dateError">
            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="dateError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>      
    </div>

    <!-- Numéro de téléphone -->
    <div class="col-md-8 mx-auto" style="padding-top: 20px;">
        <label for="telephone">Numéro de téléphone*</label>
        <input type="tel" class="input-form <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="telephone" name="telephone" required placeholder="01 02 03 04 05" pattern="[0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2} [0-9]{2}" aria-describedby="telError">    
        <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="telError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Photo de profil -->
    <div class="col-md-8 mx-auto" style="padding-top: 20px;">
        <label for="profil">Photo de profil</label>
        <input type="file" class="input-form-file <?php $__errorArgs = ['profil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profil" name="profil" aria-describedby="profilError">   
        <?php $__errorArgs = ['profil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="profilError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <h3 style="padding-top: 50px;" class="text-center">Informations en plus si vous possédez une voiture</h3>

    <div class="col-md-8 mx-auto" style="padding-top: 20px;">

        <!-- Plaque d'immatriculation -->
        <div class="col-right-input">
            <label for="immatriculation">Plaque d'immatriculation</label>
            <input type="text" class="input-form <?php $__errorArgs = ['immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="immatriculation" name="immatriculation" aria-describedby="immatError">
            <?php $__errorArgs = ['immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="immatError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Marque de la voiture -->
        <div class="col-left-input">
            <label for="marqueVoiture">Marque de la voiture</label>
            <input type="text" class="input-form <?php $__errorArgs = ['marqueVoiture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="marqueVoiture" name="marqueVoiture" value="<?php echo e(old('marqueVoiture')); ?>" aria-describedby="marqueError">
            <?php $__errorArgs = ['marqueVoiture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="marqueError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>      
    </div>

    
    <div class="col-md-8 mx-auto" style="padding-top: 20px;">
        <!-- Nombre de place max dans la voiture -->
        <div class="col-right-input">
            <label for="nbPlace">Nombre de place max</label>
            <input type="number" class="input-form <?php $__errorArgs = ['nbPlace'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nbPlace" name="nbPlace" value="<?php echo e(old('nbPlace')); ?>" aria-describedby="placeError">
            <?php $__errorArgs = ['nbPlace'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="placeError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <!-- Couleur de la voiture -->
        <div class="col-left-input">
            <label for="couleurVoiture">Couleur de la voiture</label>
            <input type="text" class="input-form <?php $__errorArgs = ['couleurVoiture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="couleurVoiture" name="couleurVoiture" value="<?php echo e(old('couleurVoiture')); ?>" aria-describedby="couleurError">
            <?php $__errorArgs = ['couleurVoiture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="couleurError" class="form-text text-muted"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>      
    </div>

    <!-- Photo de la voiture -->
    <div class="col-md-8 mx-auto" style="padding-top: 20px;">
        <label for="photoVoiture">Photo de la voiture</label>
        <input type="file" class="input-form-file <?php $__errorArgs = ['photoVoiture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="photoVoiture" name="photoVoiture" aria-describedby="photoVError">
        <?php $__errorArgs = ['photoVoiture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="photoVError" class="form-text text-muted"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
    </div>
    
    <!-- Google reCaptcha -->
    <div class="row justify-content-center align-items-center" style="padding-top: 20px;">
        <div class="g-recaptcha captcha-resize" data-sitekey="<?php echo e(config('services.recaptcha.sitekey')); ?>"></div>
    </div>

    <?php $__errorArgs = ['g-recaptcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="captcha_feedback" class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div style="padding-top: 30px;" class="row justify-content-center align-items-center">
        <p>Déja un compte ? <a href="/connexion">Connectez-vous !</a></p>
    </div>
    <div class="row justify-content-center align-items-center">
        <button type="submit" class="btn button-form">Inscription</button>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\doria\Documents\Scolaire\faculté\M2 CCI\Projet\Site_covoiturage\Covoiturage\resources\views/inscription.blade.php ENDPATH**/ ?>